fx_version 'adamant'
games { 'gta5' }

files {
    'Newtonsoft.Json.dll'
}

client_scripts {
    'Common.net.dll',
    'Common.Client.net.dll',
    'Advertisements.net.dll',
    'Advertisements.Client.net.dll'
}

server_scripts {
    'Common.net.dll',
    'Common.Server.net.dll',
    'Advertisements.net.dll',
    'Advertisements.Server.net.dll'
}