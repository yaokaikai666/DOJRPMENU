fx_version 'adamant'
games { 'gta5' }

server_scripts {
	'Common.Server.net.dll',
	'Animations.Server.net.dll',
}

client_scripts {
	'Common.Client.net.dll',
	'Animations.Client.net.dll',
}