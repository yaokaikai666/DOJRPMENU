fx_version 'adamant'
games { 'gta5' }

client_scripts {
	'Common.Client.net.dll',
	'Attachment.Client.net.dll',
}