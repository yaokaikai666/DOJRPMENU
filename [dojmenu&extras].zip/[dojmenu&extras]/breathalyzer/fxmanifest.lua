fx_version 'adamant'
games { 'gta5' }

server_scripts {
	'Common.Server.net.dll',
	'Breathalyzer.Server.net.dll',
}

client_scripts {
	'Common.Client.net.dll',
	'Breathalyzer.Client.net.dll',
}