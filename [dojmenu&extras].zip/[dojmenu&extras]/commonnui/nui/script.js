const soundEntities = {};

$(function () {
    window.addEventListener("message", (event) => {
        const item = event.data;

        if (item !== undefined) {
            if (item.type === "progressbar") {
                if (item.display === true) {
                    $("#mina").show();

                    const start = new Date();
                    const maxTime = item.time;
                    const text = item.text;
                    const timeoutVal = Math.floor(maxTime / 100);

                    animateUpdate();

                    $("#pbar_innertext").text(text);
                    $("#pbar_innerdiv").css(
                        "background-color",
                        `rgba(${item.r}, ${item.g}, ${item.b}, 0.95)`
                    );

                    function updateProgress(percentage) {
                        $("#pbar_innerdiv").css("width", `${percentage}%`);
                    }

                    function animateUpdate() {
                        const now = new Date();
                        const timeDiff = now.getTime() - start.getTime();
                        const perc = Math.round((timeDiff / maxTime) * 100);

                        if (perc <= 100) {
                            updateProgress(perc);
                            setTimeout(animateUpdate, timeoutVal);
                        } else {
                            $("#mina").hide();
                        }
                    }
                } else {
                    $("#mina").hide();
                }
            } else if (item.type === "sound") {
                if (item.status === "start") {
                    if (item.volume < 0.0) item.volume = 0.0;

                    const audio = new Audio("sounds/" + item.filename);

                    audio.load();
                    soundEntities[item.uuid] = audio;
                    audio.addEventListener("loadeddata", () => {
                        audio.volume = item.volume;
                        audio.play();
                        audio.addEventListener("ended", () => {
                            $.post(
                                "http://commonnui/soundComplete",
                                JSON.stringify({
                                    uuid: item.uuid,
                                })
                            ).then(() => soundEntities[item.uuid] = null);
                        });
                    });
                } else if (soundEntities[item.uuid]) {
                    if (item.status === "loop") {
                        soundEntities[item.uuid].loop = !soundEntities[item.uuid].loop;
                    } else if (item.status === "stop") {
                        soundEntities[item.uuid].pause();
                        soundEntities[item.uuid] = null;

                        $.post(
                            "http://commonnui/soundComplete",
                            JSON.stringify({
                                uuid: item.uuid,
                            })
                        );
                    } else if (item.status === "update") {
                        if (item.volume < 0.0) item.volume = 0.0;

                        soundEntities[item.uuid].volume = item.volume;
                    } else if (item.status === "fadeout") {
                        let vol = soundEntities[item.uuid].volume;

                        const intervalID = setInterval(function() {
	                        if (vol > 0) {
	                            vol -= 0.05;
                                if (vol > 0) soundEntities[item.uuid].volume = vol.toFixed(2);
	                        } else {
	                            clearInterval(intervalID);

                                soundEntities[item.uuid].pause();
                                soundEntities[item.uuid] = null;

                                $.post(
                                    "http://commonnui/soundComplete",
                                    JSON.stringify({
                                        uuid: item.uuid,
                                    })
                                );
	                        }
                        }, 50);
                    }
                }
            }
        }
    });
});