fx_version 'adamant'
games { 'gta5' }

server_scripts {
	'Grab.Server.net.dll',
	'Common.Server.net.dll'
}

client_scripts {
	'Grab.Client.net.dll',
	'Common.Client.net.dll'
}
