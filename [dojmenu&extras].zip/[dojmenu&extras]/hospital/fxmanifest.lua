fx_version 'adamant'
games { 'gta5' }

files {
	"ui/**/*.js",
	"ui/**/*.html",
	"ui/**/*.css",
	"ui/**/*.map",
	"Common.net.dll",
	"Newtonsoft.Json.dll"
}

ui_page "ui/index.html"

client_scripts {
	'Common.Client.net.dll',
	'Hospital.Client.net.dll'
}

server_scripts {
	'Common.Server.net.dll',
	'Hospital.Server.net.dll'
}