let playerCache = [];
let tab = 0;
let user = 0;

function loadForm() {
    $("#jailTime").val("");
    $("#jailReason").val("");
    tab = 0;
    user = 0;
    nextButton();
    $("#jailPlayers").empty();
    $("#jailPlayers").append(
        '<option selected disabled="" value="-1">Select Player</option>'
    );
    for (let i = 0; i < playerCache.length; i++) {
        $("#jailPlayers").append(
            '<option value="' +
                playerCache[i].ServerId +
                '">' +
                playerCache[i].Name +
                "</option>"
        );
    }

    $("#error").addClass("d-none");
    $("#sentencing").text("");
    $(".tab").addClass("d-none");
    $(".tab").first().removeClass("d-none");
    $("#back").addClass("disabled");
    $("#back").attr("disabled", "true");
    $(".jail-container").removeClass("d-none");
}

function nextButton() {
    if (tab === 0) {
        $("#forward").removeClass("btn-success");
        $("#forward").text("Next");
        $("#forward").attr("type", "btn");
    } else {
        $("#forward").addClass("btn-success");
        $("#forward").text("Submit");
        $("#forward").attr("type", "submit");
    }
}

function showError(msg) {
    $("#error").text(msg);
    $("#error").removeClass("d-none");
}

$("#forward").click(() => {
    if (tab === 0) {
        const p = $("#jailPlayers").val();
        if (Number.isInteger(Number(p)) && p > 0) {
            $("#error").addClass("d-none");
            user = p;
            tab = 1;
            $("#sentencing").text(
                `Hospitalization for ${$(
                    "#jailPlayers option:selected"
                ).text()}`
            );
            $(".tab").addClass("d-none");
            $(".tab").eq(tab).removeClass("d-none");
            nextButton();
            $("#back").removeClass("disabled");
            $("#back").removeAttr("disabled");
        } else {
            console.log(`invalid player: ${p}`);
            showError("Please select a valid player.");
        }
    }
});

$("#back").click(() => {
    tab--;
    if (tab < 0) {
        tab = 0;
    }

    if (tab === 0) {
        loadForm();
    }
});

$("#form").on("submit", (event) => {
    event.preventDefault();
    const time = $("#jailTime").val();
    const reason = $("#jailReason").val();
    const location = $("#hospitalLocation").val();
    console.log(location);

    if (Number.isInteger(Number(time)) && time >= 0) {
        if (reason.trim() !== "") {
            if (
                location != null &&
                Number.isInteger(Number(location)) &&
                location >= 0
            ) {
                $.post(
                    "http://hospital/hospitalNuiCallback",
                    JSON.stringify({
                        time: time,
                        reason: reason,
                        id: user,
                        location: location,
                    })
                );
                $("#jailTime").val("");
                $("#jailReason").val("");
                $("#hospitalLocation").val(-1);
            } else {
                console.log("did not select a location");
                showError("Please select a location");
            }
        } else {
            console.log(`invalid reason: ${reason}`);
            showError("Please enter a reason.");
            $("#jailReason").val("");
        }
    } else {
        console.log(`invalid time: ${time}`);
        showError("Please enter a vaild duration.");
        $("#jailTime").val("");
    }
});

$("#close").click(() => {
    $.post("http://hospital/closeUI", JSON.stringify({}));
    $(".jail-container").addClass("d-none");
});

$(function () {
    window.addEventListener("message", (event) => {
        if (event.data.type === "DISABLE_ALL_UI") {
            $(".jail-container").addClass("d-none");
        } else if (event.data.type == "DISPLAY_HOSPITAL_UI") {
            playerCache = event.data.players;
            loadForm();
        } else if (event.data.type == "DISPLAY_JAIL_ERROR") {
            showError(event.data.error);
        }
    });
});
