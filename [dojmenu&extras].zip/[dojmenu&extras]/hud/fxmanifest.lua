fx_version 'adamant'
games { 'gta5' }

client_scripts {
	'Common.Client.net.dll',
	'Hud.Client.net.dll'
}
