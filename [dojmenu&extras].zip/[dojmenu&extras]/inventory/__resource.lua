resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

client_scripts {
	'Inventory.Client.net.dll',
	'Common.Client.net.dll'

}

server_scripts {
	'Inventory.Server.net.dll',
	'Common.Server.net.dll'
}
