fx_version 'bodacious'
games { 'gta5' }

client_scripts {
	"Common.Client.net.dll",
	"KeepCalm.Client.net.dll",
}
