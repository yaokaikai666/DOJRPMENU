fx_version 'adamant'
games { 'gta5' }

files {
    'Newtonsoft.Json.dll'
}

client_scripts {
    'Common.net.dll',
    'Common.Client.net.dll',
    'Ladders.net.dll',
    'Ladders.Client.net.dll'
}

server_scripts {
    'Common.net.dll',
    'Common.Server.net.dll',
    'Ladders.net.dll',
    'Ladders.Server.net.dll'
}