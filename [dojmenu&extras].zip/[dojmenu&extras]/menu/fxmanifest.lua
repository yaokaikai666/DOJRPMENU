fx_version 'adamant'
games { 'gta5' }

client_scripts {
	'MenuAPI.dll',
	'Obs.net.dll',
	'Common.net.dll',
	'Core.Models.net.dll',
	'Menu.Client.net.dll',
	'SceneManager.net.dll',
	'Common.Client.net.dll',
	'Advertisements.net.dll'
}

files {
	"Newtonsoft.Json.dll"
}