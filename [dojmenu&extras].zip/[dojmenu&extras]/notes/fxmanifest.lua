fx_version 'adamant'
games { 'gta5' }

files {
	"nui/**/*.js",
	"nui/**/*.html",
	"nui/**/*.css",
	"nui/**/*.png",
	"Common.net.dll",
	"Newtonsoft.Json.dll"
}

ui_page "nui/index.html"

client_scripts {
	'Common.Client.net.dll',
	'Notes.Client.net.dll'
}

server_scripts {
	'Common.Server.net.dll',
	'Notes.Server.net.dll'
}