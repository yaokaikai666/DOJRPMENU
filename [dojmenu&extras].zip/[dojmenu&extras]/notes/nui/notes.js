var noteId = -1;
var resourceName = "";

$(function () {
    document.addEventListener("keydown", (event) => {
        const { key } = event;
        if (key === "Escape") {
            $("#notes").hide();
            sendNUI("close", JSON.stringify({}));
        }
    });

    $("#saveButton").click((event) => {
        if (noteId == -1) {
            sendNUI("saveNote", JSON.stringify({ text: $("#textArea").val() }));
        } else {
            sendNUI(
                "updateNote",
                JSON.stringify({
                    text: $("#textArea").val(),
                    id: noteId,
                })
            );
        }
        $("#notes").fadeOut();
        setTimeout(() => $("#textArea").val(""), 500);
    });

    window.addEventListener("message", function (event) {
        let data = event.data;
        if (data.type == "RESOURCE_NAME") {
            resourceName = data.name;
        } else if (data.type == "CREATE") {
            noteId = -1;
            $("#notes").fadeIn();
			$("#textArea").focus();
        } else if (data.type == "UPDATE") {
            (noteId = data.id), $("#textArea").val(data.text);
            $("#notes").fadeIn();
			$("#textArea").focus();
        } else if (data.type == "CLOSE_UI") {
            $("#notes").hide();
        }
    });
});

function sendNUI(name, payload) {
    $.post("http://" + resourceName + "/" + name, payload, function (datab) {
        if (datab != "ok") {
            console.log("NUI ERROR: " + datab);
        }
    });
}
