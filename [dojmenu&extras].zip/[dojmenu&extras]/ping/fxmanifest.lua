fx_version 'adamant'
games { 'gta5' }

client_scripts {
	'Common.Client.net.dll',
	'Ping.Client.net.dll'
}

server_scripts {
	'Common.Server.net.dll',
	'Ping.Server.net.dll'
}
