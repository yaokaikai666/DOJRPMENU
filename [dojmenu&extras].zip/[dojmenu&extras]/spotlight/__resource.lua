resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

client_scripts {
	'Common.Client.net.dll',
	'Spotlight.Client.net.dll',
}

server_scripts {
	'Common.Server.net.dll',
	'Spotlight.Server.net.dll',
}
