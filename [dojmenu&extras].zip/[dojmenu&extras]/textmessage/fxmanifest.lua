fx_version 'adamant'
games { 'gta5' }


client_scripts {
	'TextMessage.Client.net.dll',
	'Common.Client.net.dll'
}

server_scripts {
	'TextMessage.Server.net.dll',
	'Common.Server.net.dll'
}