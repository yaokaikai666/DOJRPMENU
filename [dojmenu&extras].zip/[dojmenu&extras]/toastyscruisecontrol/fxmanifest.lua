fx_version 'adamant'
games { 'gta5' }

client_scripts {
	'Common.Client.net.dll',
	'ToastysCruiseControl.Client.net.dll'
}
